package model;

public class StoreClient extends BaseEntity {
    public StoreClient(int id, int parentId) {
        super(id, parentId);
    }
}
