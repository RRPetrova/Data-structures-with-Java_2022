package vehicles;

public class CrossMotorcycle extends Motorcycle{

    public CrossMotorcycle(double fuel, int horsePower) {
        super(fuel, horsePower);
    }

    @Override
    public double getFuel() {
        return super.getFuel();
    }

    @Override
    public void drive(double kilometers) {
        super.drive(kilometers);
    }
}
