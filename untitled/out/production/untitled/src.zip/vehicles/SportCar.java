package vehicles;

public class SportCar extends Car{
    final static double DEFAULT_FUEL_CONSUMPTION = 3;

    public SportCar(double fuel, int horsePower) {
        super(fuel, horsePower);
        super.setFuelConsumption(DEFAULT_FUEL_CONSUMPTION);
    }

    @Override
    public double getFuelConsumption() {
        return super.getFuelConsumption();
    }

    @Override
    public double getFuel() {
        return super.getFuel();
    }

    @Override
    public void drive(double kilometers) {
        super.drive(kilometers);
    }
}
