package vehicles;

public class FamilyCar extends Car{
    public FamilyCar(double fuel, int horsePower) {
        super(fuel, horsePower);
    }

    @Override
    public double getFuel() {
        return super.getFuel();
    }

    @Override
    public void drive(double kilometers) {
        super.drive(kilometers);
    }
}
