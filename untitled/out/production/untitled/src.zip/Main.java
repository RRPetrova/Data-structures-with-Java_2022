import vehicles.SportCar;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        SportCar s = new SportCar(20,220);
        System.out.println(s.getFuel());
        s.drive(10);
        System.out.println(s.getFuel());

    }
}


