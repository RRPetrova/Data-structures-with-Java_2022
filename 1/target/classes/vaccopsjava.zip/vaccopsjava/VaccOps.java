package vaccopsjava;

import java.util.*;
import java.util.stream.Collectors;

public class VaccOps implements IVaccOps {

    List<Doctor> doctorsList;
    List<Patient> patientsList;
    Map<Doctor, List<Patient>> docP = new HashMap<>();


    public VaccOps() {
    }

    public void addDoctor(Doctor d) {

        for (Doctor doctor : doctorsList) {
            if (doctor.name.equals(d.name)) {
                throw new IllegalArgumentException();
            }
        }
        doctorsList.add(d);

    }

    public void addPatient(Doctor d, Patient p) {
        if (!doctorsList.contains(d)) {
            throw new IllegalArgumentException();
        }
        Doctor doctor = seachD(d.name);
        this.patientsList.add(p);
        List<Patient> patients = docP.get(doctor);
        if (patients.isEmpty()) {
            patients.add(p);
        }
        docP.putIfAbsent(doctor, new ArrayList<>());
    }

    private Doctor seachD(String name) {
        for (Doctor doctor : doctorsList) {
            if (doctor.name.equals(name)) {
                return doctor;
            }
        }
        return null;
    }

    private Patient searchP(String name) {
        for (Patient patient : patientsList) {
            if (patient.name.equals(name)) {
                return patient;
            }
        }
        return null;
    }


    public Collection<Doctor> getDoctors() {
        return this.doctorsList;
    }

    public Collection<Patient> getPatients() {
        return this.patientsList;
    }

    public boolean exist(Doctor d) {
        return seachD(d.name) != null;
    }

    public boolean exist(Patient p) {
        return searchP(p.name) != null;
    }


    public Doctor removeDoctor(String name) {
        if (seachD(name) == null) {
            throw new IllegalArgumentException();
        }
        Doctor doctor = seachD(name);
        this.doctorsList.remove(doctor);


        return doctor;
    }

    public void changeDoctor(Doctor from, Doctor to, Patient p) {

    }

    public Collection<Doctor> getDoctorsByPopularity(int populariry) {
        return this.doctorsList
                .stream()
                .sorted(Comparator.comparingInt(a -> a.popularity))
                .collect(Collectors.toList());
    }

    public Collection<Patient> getPatientsByTown(String town) {
        return this.patientsList
                .stream()
                .sorted(Comparator.comparing(a -> a.town))
                .collect(Collectors.toList());
    }

    public Collection<Patient> getPatientsInAgeRange(int lo, int hi) {
        return this.patientsList
                .stream()
                .filter(p -> p.age >= lo && p.age <= hi)
                .collect(Collectors.toList());

    }

    public Collection<Doctor> getDoctorsSortedByPatientsCountDescAndNameAsc() {
        return null;
    }

    public Collection<Patient> getPatientsSortedByDoctorsPopularityAscThenByHeightDescThenByAge() {
        return null;
    }

}
