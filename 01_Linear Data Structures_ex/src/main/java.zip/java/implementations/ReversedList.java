package implementations;

import java.util.Iterator;

public class ReversedList<E> {

    private final int INITIAL_CAPACITY = 2;
    private int size;
    private int capacity;
    private int tail;
    private int head;
    private Object[] elements;

    public ReversedList() {
        this.elements = new Object[INITIAL_CAPACITY];
        this.capacity = INITIAL_CAPACITY;
    }

    public void add(E element) {
        if (this.size == INITIAL_CAPACITY) {
            this.elements = grow();
        }
        this.elements[this.size++] = element;
    }

    private Object[] grow() {
        this.capacity *= 2;
        Object[] arrayListNew = new Object[this.capacity];

        for (int i = 0; i < this.elements.length; i++) {
            arrayListNew[i] = this.elements[i];
        }
        return arrayListNew;
    }


    public int size() {
        return this.size;
    }


    public int capacity() {
        return this.elements.length;
    }


    public E get(int index) { // 1 2 3
        if (index < 0 || index >= this.size) {
            throw new IndexOutOfBoundsException("Invalid index: " + index);
        }


//3-1-3
        return (E) this.elements[this.size-1-index];
    }


    public void removeAt(int index) { // __543____ // 5
        // ind 1 => 4(value) => 2(head ind)+1 = 3(ind) = 4(value)

        if (index < 0 || index >= this.elements.length) {
            throw new IndexOutOfBoundsException("Invalid index: " + index);
        }

        Object elementAboutToBeRemoved = this.elements[index];
        for (int i = index; i < this.elements.length - 1; i++) {
            this.elements[i] = this.elements[i + 1];
        }
        this.size--;
//        if (this.size < this.elements.length / 3) {
//            shrinkList();
//        }


    }


    public Iterator<E> iterator() {
        return new Iterator<E>() {


            @Override
            public boolean hasNext() {
                return false;
            }

            @Override
            public E next() {
                return null;
            }
        };
    }
}
